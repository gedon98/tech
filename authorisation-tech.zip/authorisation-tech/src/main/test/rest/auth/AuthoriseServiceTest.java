package rest.auth;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

import java.net.HttpURLConnection;

import org.junit.Test;

import jakarta.ws.rs.core.MediaType;

public class AuthoriseServiceTest {
	
	@Test
	public void simplePostJsonTest() throws IOException {
		
		URL url = new URL("http://localhost:8080/authorisation-tech/authorise");
		
		HttpURLConnection con = (HttpURLConnection)url.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
		con.setDoOutput(true);
		
		String jsonInputString = "{\"name\": \"John Smith\","
				+ " \"email\": \"test@email.com\","
				+ " \"debt\": \"100\","
				+ " \"balance\": \"0\""
				+ " }";
				
		try (OutputStream os = con.getOutputStream()) {
			    byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);	
		}			
		 assertEquals(con.getResponseCode(), 200);

	}
	
	@Test
	public void simpleFailureTest() throws IOException {		
		
		URL url = new URL("http://localhost:8080/authorisation-tech/authorise");
		
		HttpURLConnection con = (HttpURLConnection)url.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
		con.setDoOutput(true);
		
		String jsonInputString = "{\"name\": \"£$£$\","
				+ " \"email\": \"£!$£$\","
				+ " \"debt\": \"100\","
				+ " \"balance\": \"0\""
				+ " }";
				
		try (OutputStream os = con.getOutputStream()) {
			    byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);	
		}			
		 assertEquals(con.getResponseCode(), 200);
		
	}
}
