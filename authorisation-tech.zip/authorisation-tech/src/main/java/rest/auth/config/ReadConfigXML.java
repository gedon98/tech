package rest.auth.config;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import rest.auth.model.AuthRules;
import rest.auth.model.DecisionAggregates;
import rest.auth.model.decision.DecisionAggregateFactory;
import rest.auth.model.decision.IDecisionAggregator;
import rest.auth.model.rule.AuthRuleFactory;
import rest.auth.model.rule.IAuthRule;

public class ReadConfigXML {
	private static final String FILENAME = "src/main/resources/rules_config.xml";
	
	public Map<String, List<IAuthRule>> readRulesConfig() {		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Map<String, List<IAuthRule>> configuredRules= new HashMap<>();

		try {
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new File(FILENAME));

			NodeList list = doc.getElementsByTagName("resource");
	          
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				Element element = (Element) node;
				NodeList rules = element.getElementsByTagName("rule");
				List<IAuthRule> authRules = new ArrayList<>();
				for (int j = 0; j < rules.getLength(); j ++) {
					Node ruleElement = rules.item(j);
					ruleElement.getAttributes().getNamedItem("type").getNodeValue();
					IAuthRule ruleC = AuthRuleFactory.getRuleByID(AuthRules.valueOf(ruleElement.getAttributes().getNamedItem("type").getNodeValue()));
					if (ruleElement.getAttributes().getNamedItem("value") != null) {
						ruleC.setCompareValue(ruleElement.getAttributes().getNamedItem("value").getNodeValue());
					}
					authRules.add(ruleC);
				}
				configuredRules.put(element.getAttribute("id"), authRules);
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
	          e.printStackTrace();
		}		
		return configuredRules;
	}
	
	public IDecisionAggregator getDecisionAggregator() {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		try {
			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new File(FILENAME));
			
			NodeList list = doc.getElementsByTagName("aggregator");		
			if (list != null) {
				Node node = list.item(0);
				Element element = (Element) node;
				System.out.println(element.getTextContent());
				return DecisionAggregateFactory.getAggregateByID(DecisionAggregates.valueOf(element.getTextContent()));
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
	          e.printStackTrace();
		}
		return null;
	}

}
