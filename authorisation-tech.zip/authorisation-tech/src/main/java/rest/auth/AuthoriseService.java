package rest.auth;

import java.util.ArrayList;
import java.util.List;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import rest.auth.model.AuthoriseModel;
import rest.auth.model.ResourceRequestID;
import rest.auth.model.decision.Decision;
import rest.auth.model.decision.DecisionAggregateFactory;
import rest.auth.model.rule.AuthRulesForResourceFactory;
import rest.auth.model.rule.IAuthRule;
@Path("/")
public class AuthoriseService {
	
	@POST 
	@Path("/authorise")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response authorise(AuthoriseModel inModel) {
		
		List<Decision> results = new ArrayList<>();
		results.addAll(authoriseResource(ResourceRequestID.NAME, inModel.geName()));
		results.addAll(authoriseResource(ResourceRequestID.EMAIL, inModel.getEmail()));
		results.addAll(authoriseResource(ResourceRequestID.DEBIT, inModel.getDebt()));
		results.addAll(authoriseResource(ResourceRequestID.BALANCE, inModel.getBalance()));
		
		if (aggregateResults(results)) {			
			return Response.ok().build();
		} 
		return Response.status(Status.FORBIDDEN).build();
	}
	
	private boolean aggregateResults(List<Decision> results) {
		return DecisionAggregateFactory.getDecisionAggregator().performAggregation(results);
	}

	private List<Decision> authoriseResource(ResourceRequestID resourceName, String value) {
		List<IAuthRule> rules = AuthRulesForResourceFactory.getAuthRule(resourceName);
		List<Decision> results = new ArrayList<>();
		for (IAuthRule rule : rules) {			
			results.add(rule.apply(value));
		}
		return results;
	}	
}
