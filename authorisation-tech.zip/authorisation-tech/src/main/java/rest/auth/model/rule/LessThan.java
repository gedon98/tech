package rest.auth.model.rule;

import java.math.BigInteger;

import rest.auth.model.decision.Decision;

public class LessThan implements IAuthRule {

	@Override
	public Decision apply(String value) {	
		BigInteger intValue = new BigInteger(value);	
		boolean result = false;
		if (getCompareValue() != null) {
			BigInteger compareValue = new BigInteger(getCompareValue());
			result =  intValue.compareTo(compareValue) < 0 ?true:false;
		}
		return new Decision(result);
	}

}
