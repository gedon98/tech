package rest.auth.model;

public class AuthoriseModel {	

	private String name;
	private String email;
	private String debt;
	private String balance;
	
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
	public String getBalance() { return balance; }
	public void setBalance(String balance) {this.balance = balance;}
	public String geName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getDebt() { return debt; }
	public void setDebt(String debt) { this.debt = debt; }	
}
