package rest.auth.model.decision;

import java.util.List;

public class DenyOverrides implements IDecisionAggregator {

	@Override
	public boolean performAggregation(List<Decision> decisions) {
		for (Decision decision : decisions) {
			if (!decision.isPermitted()) {
				return false;
			}
		}
		return true;
	}
}
