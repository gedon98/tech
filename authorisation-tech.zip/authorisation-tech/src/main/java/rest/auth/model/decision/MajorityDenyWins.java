package rest.auth.model.decision;

import java.util.List;

public class MajorityDenyWins implements IDecisionAggregator {

	@Override
	public boolean performAggregation(List<Decision> decisions) {
		int denyTotal = 0;
		int permitTotal = 0;
		for (Decision decision : decisions) {
			if (decision.isPermitted()) {
				permitTotal++;			
			} else {
				denyTotal++;
			}
		}
		return denyTotal >= permitTotal;
	}
}
