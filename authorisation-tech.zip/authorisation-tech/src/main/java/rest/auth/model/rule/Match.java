package rest.auth.model.rule;

import rest.auth.model.decision.Decision;

public class Match implements IAuthRule {
	
	String compareValue = "";

	@Override
	public Decision apply(String value) {
		boolean result = false;
		if (value != null) {
			result = value.matches(getCompareValue());
		}
		return new Decision(result);
	}

	@Override
	public void setCompareValue(String value) { compareValue = value; }
	@Override public String getCompareValue() { return compareValue; }
}
