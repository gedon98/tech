package rest.auth.model.rule;

import rest.auth.model.AuthRules;

public class AuthRuleFactory {
	
	public static IAuthRule getRuleByID(AuthRules ruleId) {
		if (AuthRules.MATCH== ruleId) {
			return new Match();
		}
		if (AuthRules.GREATER_THAN == ruleId) {
			return new Match();
		}
		if (AuthRules.LESS_THAN == ruleId) {
			return new Match();
		}
		return new Exists();
	}

}
