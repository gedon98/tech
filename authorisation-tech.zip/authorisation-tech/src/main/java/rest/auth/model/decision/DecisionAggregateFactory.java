package rest.auth.model.decision;

import rest.auth.config.ReadConfigXML;
import rest.auth.model.DecisionAggregates;

public class DecisionAggregateFactory {
	
	
	public static IDecisionAggregator aggr;
	
	public static IDecisionAggregator getDecisionAggregator() {
		if (aggr == null) {
			aggr= new ReadConfigXML().getDecisionAggregator();
		}
		return aggr;
	}
	
	public static IDecisionAggregator getAggregateByID(DecisionAggregates aggrId) {
		if (DecisionAggregates.PERMIT_OVERRIDES_DENY == aggrId) {
			return new PermitOverrides();
		}
		if (DecisionAggregates.MAJORITY_WINS_BIAS_DENY== aggrId) {
			return new MajorityDenyWins();
		}
		if (DecisionAggregates.MAJORITY_WINS_BIAS_PERMIT == aggrId) {
			return new MajorityPermitWins();
		}
		return new DenyOverrides();
	}
}
