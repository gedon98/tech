package rest.auth.model.decision;

public class Decision {
	
	private boolean permit = false;
	
	public Decision(boolean permit) {
		this.permit = permit;
	}
	
	public boolean isPermitted() {
		return permit;
	}

	public void setPermitted(boolean permit) {
		this.permit = permit;	
	}	
}
