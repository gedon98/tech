package rest.auth.model.rule;

import java.util.List;
import java.util.Map;

import rest.auth.config.ReadConfigXML;
import rest.auth.model.ResourceRequestID;

public final class AuthRulesForResourceFactory {
	
	public static Map<String, List<IAuthRule>> authRules; 
	//public static Agg
		
	public static List<IAuthRule> getAuthRule(ResourceRequestID ruleKey) {
		if (authRules == null) {
			authRules = new ReadConfigXML().readRulesConfig();
		}
		return authRules.get(ruleKey.toString());
	}
}
