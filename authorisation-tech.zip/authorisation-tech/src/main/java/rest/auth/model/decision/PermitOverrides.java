package rest.auth.model.decision;

import java.util.List;

public class PermitOverrides implements IDecisionAggregator {

	@Override
	public boolean performAggregation(List<Decision> decisions) {
		for (Decision decision : decisions) {
			if (decision.isPermitted()) {
				return true;
			}
		}
		return false;
	}
}
