package rest.auth.model.decision;

import java.util.List;

public interface IDecisionAggregator {
	
	public boolean performAggregation(List<Decision> decisions);
}
