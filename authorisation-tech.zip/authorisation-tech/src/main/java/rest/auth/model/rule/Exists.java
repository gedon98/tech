package rest.auth.model.rule;

import rest.auth.model.decision.Decision;

public class Exists implements IAuthRule {

	@Override
	public Decision apply(String value) {
		return new Decision(value != null && !value.isEmpty());
	}
}
