package rest.auth.model.rule;

import rest.auth.model.decision.Decision;

public interface IAuthRule {
	public Decision apply(String value);
	
	default public void setCompareValue(String value) {
	}
	
	default public String getCompareValue() {
		return null;
	}	
}
