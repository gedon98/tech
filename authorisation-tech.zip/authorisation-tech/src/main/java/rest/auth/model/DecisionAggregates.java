package rest.auth.model;

public enum DecisionAggregates {
	
	DENY_OVERRIDES_PERMIT,
	PERMIT_OVERRIDES_DENY,
	MAJORITY_WINS_BIAS_PERMIT,	
	MAJORITY_WINS_BIAS_DENY,
}
