package rest.auth.model;

public enum AuthRules {
	
	MATCH,
	GREATER_THAN,
	LESS_THAN,
	EXISTS;	
}
