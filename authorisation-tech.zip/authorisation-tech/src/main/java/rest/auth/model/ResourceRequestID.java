package rest.auth.model;

public enum ResourceRequestID {
	
	NAME("name"),
	EMAIL("email"),
	DEBIT("debit"),
	BALANCE("balance");
	
	 private final String value;
	 ResourceRequestID(final String s) { value = s; }
	 public String toString() { return value; }
}
