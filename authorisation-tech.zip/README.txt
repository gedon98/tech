Most Functionality has been implemented, however I've not build a full set of test classes due to time constraints as I've not build the configuration to be injectable at test run time

I also think there is an issue with the greater than a less than rules, but I did have time to debug it properly

The main purpose of the design is that rules and aggregators can be easily added via the Enumerations and Factory classes.

I wasn't sure if new resoure request items should be added simply as well, but these to can be added with limited changes to the model and the main service class.

Thanks

Paul Lynch